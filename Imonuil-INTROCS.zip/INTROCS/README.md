This is a team activity of 3 random members. You have been randomly assigned to the random group. Part of this evaluation is to test the "soft skills" of the student and the ability to work as a team member.

You can and must communicate over MS Team Project. Create a temporary MS Team project and add all members (including instructor: Nurlan Shaidullaev) to the project. For the sake of transparency and assessment.

You may not change your sit places. All the work must be conducted only online without talking. Only texting is allowed. (Fast typing skill was to be practiced anyway during the whole semester smile.)

A grade of 70 points is awarded in case the activity is completed in full according to the instructions.

Choose a "Leader" who is going to create a Repository on his own GitHub account.

The "leader" for this activity must add other 2 members as contributors to provide read/write access to the repository.

Every member must download the online project to the local PC and continue through Terminal/Command-Line.

Create 27 commits on the Master branch (9 commits by each Team member) by developing single Python file. Develop main.py file with three simple methods: developer1method(), developer2method(), developer3method(). Every method is developed by single developer. Every method must print the following info: name, surname, email, cohort, age, gender, birthdate, speciality, country of origin. Hint: 9 commits = 9 print statements.

Create 3 branches (Feature1, Feature2, Feature3) that must be visible online and offline.

On each separate branch, each member must create 10 own commits. Commit messages must follow best practices to construct the messages. With team of three develop feature1.py, feature2.py, feature3.py files. Functionality of the file is up you. You can print 10 different statements or get 10 different inputs.

No merge is to be done in any branch.
