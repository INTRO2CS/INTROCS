
"""Python code goes here"""
def developer1method():

    print("name: {}\n ".format("Umidbek"))
    print("surname: {}\n ".format("Ulmasov"))
    print("email: {}\n ".format("umidbek.ulmasov_2025@gmail.com"))
    print("cohort: {}\n ".format("CS freshman"))
    print("age: {}\n ".format("20"))
    print("gender: {}\n ".format("Male"))
    print("birthdate: {}\n ".format("25.03.2002"))
    print("speciality: {}\n ".format("Frontend"))
    print("country: {}\n ".format("Tajikistan"))

def developer2method():
    print("name: {}\n ".format("Imonuil"))
    print("surname: {}\n ".format("Suleimanov"))
    print("email: {}\n ".format("imasuleymanov@gmail.com"))
    print("cohort: {}\n ".format("CS freshman"))
    print("age: {}\n ".format("20"))
    print("gender: {}\n ".format("Male"))
    print("birthdate: {}\n ".format("31.05.2001"))
    print("speciality: {}\n ".format("Backend"))
    print("country: {}\n ".format("Tajikistan"))
    

    grades = [67, 100, 87, 56]

    color = "Blue"

    grades = [67, 100, 87, 
    
    my_list = [1, 2, 3, 4, 5]

    <var_name> = <value>


print("Hello, World!")

age = 56

name = "Nora"
color = "Blue"

hello = [67, 100, 87, 56]
